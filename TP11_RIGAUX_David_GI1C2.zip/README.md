# Bienvenue !

Pour compiler et exécuter le programme TD6, il vous suffit de suivre l'unique étape ci-dessous.
## Compilation
   Ouvrir le terminal dans le dossier racine du programme. Il suffit maintenant 	d'entrer la ligne suivante terminal :
		`make all`.\
	Cette commande va compiler le programme.
## Exécution
Dirigez-vous maintenant dans le dossier `bin/` et lancer la commande suivante dans le terminal : `./main -in fichierIn -out fichierOut -arg1 arg2`.
* `arg1` : `-gris` (Niveau de gris )ou `-seuil` (Seuillage)
* `arg2` : Valeur de seuillage si seuillage demandé