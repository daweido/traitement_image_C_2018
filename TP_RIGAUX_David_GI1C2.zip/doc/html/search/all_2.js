var searchData=
[
  ['simagepbm',['sImagePBM',['../structs_image_p_b_m.html',1,'']]],
  ['simagepgm',['sImagePGM',['../structs_image_p_g_m.html',1,'']]],
  ['simageppm',['sImagePPM',['../structs_image_p_p_m.html',1,'']]],
  ['spixel',['sPixel',['../structs_pixel.html',1,'']]]
];
