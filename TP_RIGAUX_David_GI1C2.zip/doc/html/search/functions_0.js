var searchData=
[
  ['cleanstdin',['cleanStdin',['../menu_8c.html#afa4fbefcb2bcc55692e3b358a5e92686',1,'cleanStdin(void):&#160;menu.c'],['../menu_8h.html#afa4fbefcb2bcc55692e3b358a5e92686',1,'cleanStdin(void):&#160;menu.c']]],
  ['clearscr',['clearScr',['../menu_8c.html#a4f3a436404e9fa34f5d488f9d3fb9838',1,'clearScr(void):&#160;menu.c'],['../menu_8h.html#a4f3a436404e9fa34f5d488f9d3fb9838',1,'clearScr(void):&#160;menu.c']]]
];
