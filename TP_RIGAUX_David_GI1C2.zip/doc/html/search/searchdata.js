var indexSectionsWithContent =
{
  0: "bcmrst",
  1: "s",
  2: "ms",
  3: "cmrst",
  4: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Pages"
};

