//
// Created by David Rigaux on 09/01/2018.
//

#ifndef TP13_PROG_PROC_2018_ING1_TRAITEMENTIMAGES_H
#define TP13_PROG_PROC_2018_ING1_TRAITEMENTIMAGES_H

#include "es.h"
#include "traitementPPM.h"
#include "traitementPGM.h"
#include "traitementPBM.h"

void traitementImage(FILE *fichier, char *nomFichierOut);

#endif //TP13_PROG_PROC_2018_ING1_TRAITEMENTIMAGES_H
