//
// Created by David Rigaux on 08/01/2018.
//

#include "es.h"

FILE *ouvertureFichierLecture(void) {
    FILE *fp;
    fp = fopen("/Users/davidrigaux/Desktop/ppm.ppm", "r");
    return fp;
}


int recupTypeImage(FILE *fp) {
    char buff[255];

    fscanf(fp,"%s\n",buff);
    printf("%s",buff);
    return 1;
}