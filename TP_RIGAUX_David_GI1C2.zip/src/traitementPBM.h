//
// Created by David Rigaux on 09/01/2018.
//

#ifndef TP13_PROG_PROC_2018_ING1_TRAITEMENTPBM_H
#define TP13_PROG_PROC_2018_ING1_TRAITEMENTPBM_H

#include "es.h"

sPBM chargementPBM(FILE *fichier);

void sauvegardePBM(FILE *fichier, sPBM spbm_image);

#endif //TP13_PROG_PROC_2018_ING1_TRAITEMENTPBM_H
