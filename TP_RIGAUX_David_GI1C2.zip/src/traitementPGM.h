//
// Created by David Rigaux on 09/01/2018.
//

#ifndef TP13_PROG_PROC_2018_ING1_TRAITEMENTPGM_H
#define TP13_PROG_PROC_2018_ING1_TRAITEMENTPGM_H

#include "es.h"

sPGM chargementPGM(FILE *fichier);

#endif //TP13_PROG_PROC_2018_ING1_TRAITEMENTPGM_H
