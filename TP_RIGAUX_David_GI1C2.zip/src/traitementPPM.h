//
// Created by David Rigaux on 09/01/2018.
//

#ifndef TP13_PROG_PROC_2018_ING1_TRAITEMENTPPM_H
#define TP13_PROG_PROC_2018_ING1_TRAITEMENTPPM_H

#include "es.h"

sPPM chargementPPM(FILE *fichier);

#endif //TP13_PROG_PROC_2018_ING1_TRAITEMENTPPM_H
